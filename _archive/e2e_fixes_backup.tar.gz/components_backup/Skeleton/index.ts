export { Skeleton, type SkeletonProps } from './Skeleton'
